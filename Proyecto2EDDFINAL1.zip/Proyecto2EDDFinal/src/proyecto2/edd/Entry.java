/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto2.edd;

/**
 *
 * @author gabriellavetencourt
 */
public class Entry {
    private String key; // La clave del elemento, se usa para tener una posición única  y buscar su posición en el array de "buckets".
    private Archivo value; //El valor de la clave en el hashtable. Representar el archivo.
    private Entry next; //Puntero al siguiente. se utiliza para manejar colisiones en el hashtable. 
 
        
        public Entry(String key, Archivo value, Entry next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }

    /**
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key the key to set
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * @return the value
     */
    public Archivo getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(Archivo value) {
        this.value = value;
    }

    /**
     * @return the next
     */
    public Entry getNext() {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext(Entry next) {
        this.next = next;
    }
    
}
