/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2.edd;

import javax.swing.JOptionPane;

/**
 *
 * @author daniela
 */
public class HashTable {
    private int DEFAULT_CAPACITY;  // Definimos un tamaño por defecto para el hashtable
    private int numElementos;
    private Entry[] buckets; //donde se almacenan los pares key-value

    // Constructor para crear un hashtable con tamano por defecto
    public HashTable() {
        this.buckets = new Entry[16];
        this.numElementos = 0;
    }

    // Constructor para crar un hashtable con tamaño especifico
    public HashTable(int capacity) {
        this.buckets = new Entry[capacity];
        this.numElementos = 0;
    }

    // Método para obtener el valor asociado a una clave
    public Archivo get(String key) {
        int bucketIndex = getBucketIndex(key);
        Entry entry = buckets[bucketIndex];
        while (entry != null) {
            if (entry.getKey().equals(key)) {
                return entry.getValue();
            }
            entry = entry.getNext();
        }
        return null;
    }

    // Método para obtener el valor asociado a una clave
    public String getByAuthor(String key) {
        String options = ""; // string vacio que va a tener la info 
        boolean found = false; // para verificar si se encontro el autor en el archivo
        for (int i = 0; i < this.buckets.length; i++) {
            if (this.buckets[i] != null) {
                Entry currentNode = this.buckets[i];
                found = false;
                while (currentNode != null) {
                    Nodo aux = currentNode.getValue().getAutor().getpFirst();

                    while (aux != null) {
                        //Compara si  key coincide con el autor actual
                        if (key.trim().equalsIgnoreCase(aux.getData().toString().trim())) {
                            found = true; //encontro al autor
                        }
                        aux = aux.getpNext();
                    }
                    if (found) {
                        options += currentNode.getKey() + "\n"; //si se encontró el autor, concatena el título del artículo.
                    }  
                    currentNode = currentNode.getNext();
                }
            }
        }
        return options;
    }

    public String getBypClave(String key) {
        String options = ""; // string vacio que va a tener la info
        boolean found = false; // para verificar si se encontro el autor en el archivo
        for (int i = 0; i < this.buckets.length; i++) {
            if (this.buckets[i] != null) {
                Entry currentNode = this.buckets[i];
                found = false;
                while (currentNode != null) {
                    Nodo aux = currentNode.getValue().getpClave().getpFirst();

                    while (aux != null) {
                        //Compara si  key coincide con la palaabra clave actual
                        if (key.trim().equalsIgnoreCase(aux.getData().toString().trim())) {
                            found = true; //encontro la palabra clave
                        }
                        aux = aux.getpNext();
                    }
                    if (found) {
                        //si se encontró la palabra clave, concatena el título del artículo.
                        options += currentNode.getKey() + "\n";
                    }
                    currentNode = currentNode.getNext();
                }
            }
        }
        return options;
    }

    // Método para añadir un par key-value al hastable
    public void put(String key, Archivo value) {
        System.out.println(value.getAutor().print());
        int bucketIndex = getBucketIndex(key);
        Entry entry = buckets[bucketIndex];
        while (entry != null) {
            if (entry.getKey().equals(key)) {
                //entry.getValue() = value;
                entry.setValue(value);

                return;
            }
            entry = entry.getNext();
        }
        Entry newEntry = new Entry(key, value, buckets[bucketIndex]);
        buckets[bucketIndex] = newEntry;
        this.numElementos += 1;
    }

    // Método para eliminar un par key-value del hashtable
    public void remove(String key) {
        int bucketIndex = getBucketIndex(key);
        Entry entry = buckets[bucketIndex];
        Entry previous = null;
        while (entry != null) {
            if (entry.getKey().equals(key)) {
                if (previous == null) {
                    buckets[bucketIndex] = entry.getNext();
                } else {
                    previous.setNext(entry.getNext());
                }
                return;
            }
            previous = entry;
            entry = entry.getNext();
        }
        this.numElementos -= 1;
    }

    // Método para obtener el índice del bucket correspondiente a una clave
    private int getBucketIndex(String key) {
        int hashCode = transformarClave(key);
        int bucketIndex = hashCode % buckets.length;
        return bucketIndex;

    }

    public int transformarClave(String clave) {
        int d = 0;

        for (int i = 0; i < clave.length(); i++) {
            d += (i + 1) * (int) clave.charAt(i); //ASCII
        }

        if (d < 0) { //se supera el máximo de int y se generan numeros negativos 
            d = -d; //se convierte en positivo el numero            
        }
        return d;
    }

    public void print() {
        for (int i = 0; i < this.buckets.length; i++) {
            if (this.buckets[i] != null) {
                Entry currentNode = this.buckets[i];
                while (currentNode != null) {
                    System.out.println(currentNode.getKey().toString() + ": " + currentNode.getValue().toString());
                    currentNode = currentNode.getNext();
                }
            }
        }
    }

    //guarda los archivos asociados con la estructura de datos del hashtable
    public void saveFiles() {
        String content = "";
        for (int i = 0; i < this.buckets.length; i++) {
            if (this.buckets[i] != null) {
                //Asigna el elemento actual del array buckets a la variable currentNode.
                Entry currentNode = this.buckets[i];
                while (currentNode != null) {

                    //Llama a guardar() que "guarda" el archivo que tiene la investigación.
                    currentNode.getValue().guardar();
                    currentNode = currentNode.getNext();
                }
            }
        }
        
        if(numElementos>0){
                  JOptionPane.showMessageDialog(null, "Las investigaciones han sido guardadas.");
        }
    }

    //agrega los títulos de los arhcivos existentes en el hashtable a la lista desplegable en la interfaz Analizar
    public void createOptions(Analizar analizar) {

        for (int i = 0; i < this.buckets.length; i++) {
            if (this.buckets[i] != null) {
                Entry currentNode = this.buckets[i];
                while (currentNode != null) {

                    analizar.listaResumenes.addItem(currentNode.getKey()); //Agrega los títulos
                    currentNode = currentNode.getNext();
                }
            }
        }
    }

    //agrega los nombres de los autores de los archivos existentes en el hashtable a la lista desplegable en la interfaz Autor
    public void createOptionsAuthors(Autor options) {

        for (int i = 0; i < this.buckets.length; i++) {
            if (this.buckets[i] != null) {
                Entry currentNode = this.buckets[i];
                while (currentNode != null) {
                    Nodo aux = currentNode.getValue().getAutor().getpFirst();
                    while (aux != null) {
                        boolean test = true; //empieza en true para verificar si el autor actual ya existe en la lista D autores.
                        
                        for (int j = 0; j < options.LDAutores.getItemCount(); j++) {
                            //Compara si el autor actual coincide con la posición j en la lista D.
                            if ((aux.getData().toString().trim()).equals((options.LDAutores.getItemAt(j)).trim())) {
                                test = false; // si coincide entonces false, para que no se repitan autores que esten en varias investigaciones
                            }

                        }

                        if (test) {
                            options.LDAutores.addItem(aux.getData().toString()); //agrega los autores
                        }
                        aux = aux.getpNext();
                    }
                    currentNode = currentNode.getNext();
                }
            }
        }
    }
//agrega las palabras clave de los archivos existentes en el hashtable a la lista desplegable en la interfaz pClave. 
    public void createOptionspClave(pClave options) {

        for (int i = 0; i < this.buckets.length; i++) {
            if (this.buckets[i] != null) {
                Entry currentNode = this.buckets[i];
                while (currentNode != null) {
                    Nodo aux = currentNode.getValue().getpClave().getpFirst();
                    while (aux != null) {
                        boolean test = true; ////empieza en true para verificar si la palabra clave actual ya existe en la lista D autores.
                        for (int j = 0; j < options.LDpClave.getItemCount(); j++) {
                            //Compara si la palabra actual coincide con la posición j en la lista D.
                            if ((aux.getData().toString().trim()).equals((options.LDpClave.getItemAt(j)).trim())) {
                                test = false; // si coincide entonces false, para que no se repitan palabras claves que esten en varias investigaciones
                            }

                        }

                        if (test) {
                            options.LDpClave.addItem(aux.getData().toString()); //Agg palabras clave a la lista desplegable
                        }
                        aux = aux.getpNext();
                    }
                    currentNode = currentNode.getNext();
                }
            }
        }
    }

    public int getNumElementos() {
        return numElementos;
    }

    //verifica si el hashtable tiene una clave (la que recibe como parametro)
    public boolean containsKey(String key) {
        //Llama getBucketIndex() con key para obtener el índice del bucket donde se almacena la clave 
        int bucketIndex = getBucketIndex(key);
        Entry entry = buckets[bucketIndex];
        while (entry != null) {
            if (entry.getKey().equals(key)) { //si las claves coinciden
                return true;
            }
            entry = entry.getNext();
        }
        return false; 
    }
}
