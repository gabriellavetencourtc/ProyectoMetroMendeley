/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2.edd;

import javax.swing.JOptionPane;

/**
 *
 * @author daniela
 */
public class Lista<T> {

    private Nodo<T> pFirst;
    private Nodo<T> pLast;
    private int size;

    public Lista() {
        this.pFirst = null;
        this.pLast = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return getpFirst() == null;
    }


    public void insertarAlFinal(T data) {
    
        Nodo<T> nuevoNodo = new Nodo<>(data);
        if (this.getSize() == 0) {
            this.setpFirst(nuevoNodo);
            this.setpLast(nuevoNodo);
        } else {
            this.getpLast().setpNext(nuevoNodo);
            this.setpLast(nuevoNodo);
        }
        this.setSize(this.getSize() + 1);
    }


    public Nodo pNextNodo(Nodo  pNext){
        if(pNext.getpNext() != null){
            pNext = pNext.getpNext();
            return pNext;                    
        }
        else{
            return null;
        }
    }
    
    public String print(){
        Nodo aux = this.pFirst;
        if (this.isEmpty()){
//            JOptionPane.showMessageDialog(null, "La lista se encuentra vacía");
        }
        else{
                    
            String print = "";             

            for (int i = 0; i< this.size; i++ ){               

                print += aux.getData() + "\n";
               
                aux = aux.getpNext();
                
               }
            return print;
   
            }
        return null;
        }
    
    
    // NODO POR INDICE
    public Nodo buscarNodo(int posicion){
        if(isEmpty()){
            JOptionPane.showMessageDialog(null, "La lista se encuentra vacía");
            return null;
        }else if(posicion >= this.size){
            JOptionPane.showMessageDialog(null,"Error! intente de nuevo");
            return null;
        }else{
            Nodo aux = pFirst;
            
            for (int i = 0; i < posicion; i++) {
                aux = aux.getpNext();
            }return aux;
        }
    }
    


    /**
     * @return the pFirst
     */
    public Nodo<T> getpFirst() {
        return pFirst;
    }

    /**
     * @param pFirst the pFirst to set
     */
    public void setpFirst(Nodo<T> pFirst) {
        this.pFirst = pFirst;
    }

    /**
     * @return the pLast
     */
    public Nodo<T> getpLast() {
        return pLast;
    }

    /**
     * @param pLast the pLast to set
     */
    public void setpLast(Nodo<T> pLast) {
        this.pLast = pLast;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }
    
    
    
    
}