/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2.edd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author daniela
 */
public class Archivo {
    
    private String titulo;
    private Lista autor;
    private String cuerpo;
    private Lista pClave;
    private int size;  //número de elementos que posee la tabla
    private File archivoCompartido;


    public Archivo(String nombretxt){
        leer(nombretxt);
            
    }
    
    public void setArchivoCompartido(File f) {
        archivoCompartido = f;
    }

    public File getArchivoCompartido() {
        return archivoCompartido;
    }
    
    
    public void leer(String path){

        File file = new File(path);
        String aux = "";
        String leer;
        String[] split;
       
        int cont = 0;
        
        try
        {
            FileReader fr = new FileReader(file);
            

            BufferedReader br = new BufferedReader(fr);
           
            //Lee línea por línea y usa "//" como separador cuando la linea no este vacia.
            while((leer = br.readLine()) != null)
            {
                if(!leer.equals("")){
                    aux += leer + "//";   
                }
            }
            
            br.close();
            
            split = aux.split("//");
            
            
            this.setTitulo(split[0]); //titulo
            
           
            
            while(cont < split.length){
                if(split[cont].equals("Resumen")){ //autores
                    break;
                }
                cont++;                    
            }
            //lista  aux2 que guarda  los autores entre posición 2 y la posición cont en el array split.
            
            Lista aux2 = new Lista();
            
            for (int i = 2; i < cont; i++) 
            {
                    aux2.insertarAlFinal(split[i]);
                
            }
            
            this.setAutor(aux2);
           
   
            this.setCuerpo(split[cont+1]); //reusmen
   
            String pClave = split[cont+2]; //palabras clave
            
            // encuentra palabras clave, las divide con comas y las almacena en lista lista.
            Lista lista = new Lista();
            
            
            
            if(pClave.contains("Palabras Claves:")){
                String replace = pClave.replace("Palabras Claves:", "").trim();
                String[] palabras = replace.split(",");
                
                for (int i = 0; i < palabras.length; i++) {
                    
           
                    lista.insertarAlFinal(palabras[i].replace(".", "").trim());
                }
                
                this.setpClave(lista);
                
            }else if(pClave.contains("Palabras claves:")){
                String replace = pClave.replace("Palabras claves:", "").trim();
                String[] palabras = replace.split(",");
                
                for (int i = 0; i < palabras.length; i++) {
                   
                    
                   
                    lista.insertarAlFinal(palabras[i].replace(".", "").trim());
                }
                
                this.setpClave(lista);
            }
            
 
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al leer archivo! Intente de nuevo");
        }
    }
    
          
    
    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return the autor
     */
    public Lista getAutor() {
        return autor;
    }

    /**
     * @param autor the autor to set
     */
    public void setAutor(Lista autor) {
        this.autor = autor;
    }

    /**
     * @return the cuerpo
     */
    public String getCuerpo() {
        return cuerpo;
    }

    /**
     * @param cuerpo the cuerpo to set
     */
    public void setCuerpo(String cuerpo) {
        this.cuerpo = cuerpo;
    }

    /**
     * @return the pClave
     */
    public Lista getpClave() {
        return pClave;
    }

    /**
     * @param pClave the pClave to set
     */
    public void setpClave(Lista pClave) {
        this.pClave = pClave;
    }

    /**
     * @return the size
     */
    public int Size() {
        return size;
    }

    /**
     * @param size
     */
    public void Size(int size) {
        this.size = size;
    }
    
    public void guardar(){
        FileInputStream in = null;
        try {
  
            in = new FileInputStream(this.archivoCompartido);
            String pathArchivo = "resumenes/"+this.archivoCompartido.getName();
            File myObj = new File(pathArchivo);
            FileOutputStream out = new FileOutputStream(myObj);
            try {
                
                int n;
               //Lee el archivo byte por byte hasta que no haya más para leer.
                while ((n = in.read()) != -1) {

                    out.write(n); //Escribe los bytes leídos en el archivo 
                }
            }
            finally {
                if (in != null) {

                    in.close(); //Cierra el flujo de entrada
                }

                if (out != null) {
                    out.close();// Cierra el flujo de salida
                }
            }
            System.out.println("File Copied");
        }
        catch (Exception e) {
            Logger.getLogger(Archivo.class.getName()).log(Level.SEVERE, null, e);
        }        
    }
    
    
}
