/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2.edd;

/**
 *
 * @author daniela
 */
public class ArreglopClave {
    
    private String pClave;
    private String titulo;
    private Lista titulos;

    public ArreglopClave(String pClave, String titulo) {
        this.pClave = pClave;
        this.titulo = titulo;
    }
    
    public ArreglopClave(String pClave)
    {
        this.pClave = pClave;
        this.titulos = new Lista();
    }
    

    /**
     * @return the pClave
     */
    public String getpClave() {
        return pClave;
    }

    /**
     * @param pClave the pClave to set
     */
    public void setpClave(String pClave) {
        this.pClave = pClave;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return the titulos
     */
    public Lista getTitulos() {
        return titulos;
    }

    /**
     * @param titulos the titulos to set
     */
    public void setTitulos(Lista titulos) {
        this.titulos = titulos;
    }
    
}
